<?php
namespace App\Core\Contracts\Payroll;

interface iFormula {
    public function calculate();
}