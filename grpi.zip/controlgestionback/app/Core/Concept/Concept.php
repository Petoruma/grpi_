<?php
namespace App\Core\Concept;


class Concept{

    public function calculate()
    {
        /* Nuevo example */
        return "hello world!";
    }
    
}

?>