<?php

namespace App\Models\Catalogs;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CatRulesImssDeduction extends Model
{
    use HasFactory;
    protected $table = "cat_rules_imss_deductions";
}
