<?php

namespace App\Models\Catalogs;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CatConceptImssDeduction extends Model
{
    use HasFactory;
    protected $table="cat_concept_imss_deductions";
}
