<?php

namespace App\Models\Catalogs;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CatBankAccountType extends Model
{
    use HasFactory;

    const CLABE = 3;
}
